import type { ButtonHTMLAttributes } from "react";

type Variant = "primary" | "secondary";
type Size = "sm" | "md";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

/**
 * Button — reads ONLY semantic tokens (never raw palette values).
 * Colors flip automatically with [data-theme="dark"] on a parent element.
 */
export function Button({ variant = "primary", size = "md", style, ...props }: ButtonProps) {
  const base: React.CSSProperties = {
    fontFamily: "var(--font-family-sans)",
    fontWeight: "var(--font-weight-medium)" as unknown as number,
    borderRadius: "var(--radius-control)",
    border: "1px solid transparent",
    cursor: "pointer",
    padding: size === "sm" ? "var(--space-inset-sm) var(--space-inset-md)"
                           : "var(--space-inset-md) var(--space-inset-lg)",
    fontSize: size === "sm" ? "var(--font-size-sm)" : "var(--font-size-md)",
  };

  const variants: Record<Variant, React.CSSProperties> = {
    primary: {
      background: "var(--color-action-primary)",
      color: "var(--color-text-on-action)",
    },
    secondary: {
      background: "var(--color-bg-subtle)",
      color: "var(--color-text-default)",
      borderColor: "var(--color-border-default)",
    },
  };

  return <button style={{ ...base, ...variants[variant], ...style }} {...props} />;
}
